#include "queue.hpp"
#include <iostream>

using namespace std;

int main(){
    List l = NULL;

    
    Lista_insert(&l, 5);
    Lista_insert(&l, 2);
    Lista_insert(&l, 6);
    Lista_insert(&l, 8);
    Lista_insert(&l, 10);
    Lista_insert(&l, 1);
    
    Lista_print(l);

    Lista_remove(&l, 2);

    Lista_print(l);

    Lista_remove(&l, 1);
    Lista_remove(&l, 10);

    Lista_print(l);

    Lista_delete(&l);

    return 0;
}