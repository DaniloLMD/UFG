#ifndef __QUEUE_HPP__
#define __QUEUE_HPP__

typedef struct node* Node;
typedef Node List;

//apaga uma lista
void Lista_delete(List* list);

//insere um elemento na lista de maneira ordenada
void Lista_insert(List* list, int val);

//remove o valor da lista, se ele existir
void Lista_remove(List* list, int val);

//printa uma lista
void Lista_print(List list);

#endif