#include "queue.hpp"
#include <iostream>

struct node{
    int data;
    node* next;
};

Node Node_new(int data){
    Node new_node = (Node) malloc(sizeof(node));
    new_node->data = data;
    new_node->next = NULL;
    return new_node;
}

void Lista_delete(List* list_ref){

    List list = *list_ref;

    if(list == NULL)
        return;

    Node atual = list;
    Node anterior;

    while(atual != NULL){
        anterior = atual;
        atual = atual->next;
        free(anterior);
    }
    *list_ref = NULL;
}

void Lista_insert(List* list_ref, int val){

    if(*list_ref == NULL){
        *list_ref = Node_new(val);
        return;
    }

    Node list = *list_ref;
    Node new_node = Node_new(val);
    Node atual = list;
    Node anterior = NULL;

    while(atual != NULL){
        if(atual->data >= val){
            if(atual != list){
                anterior->next = new_node;
            }
            else{
                *list_ref = new_node;
            }

            new_node->next = atual;
            
            
            return;
        }
        anterior = atual;
        atual = atual->next;
    }
    anterior->next = new_node;    
}

void Lista_remove(List* list_ref, int val){
    List list = *list_ref;

    List atual = list, anterior = NULL;

    while(atual != NULL){
        if(atual->data == val){

            if(atual == list)
                *list_ref = list->next;
            else
                anterior->next = atual->next;
            

            free(atual);
            return;
        }

        anterior = atual;
        atual = atual->next;
    }
}

void Lista_print(List list){
    Node atual = list;
    while(atual != NULL){
        std::cout << atual->data << " ";

        if(atual->next != NULL)
            std::cout << "-> ";

        atual = atual->next;
    }
    std::cout << std::endl;
}